"""
ERMOS - Tela de Menu Principal
"""
import math
from kivy.uix.screenmanager import Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle, Ellipse, Line, RoundedRectangle
from kivy.core.text import Label as CoreLabel
from kivy.core.window import Window


class MenuScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.anim = 0
        self.layout = FloatLayout()
        self.canvas_widget = MenuCanvas(size=Window.size, pos=(0, 0))
        self.layout.add_widget(self.canvas_widget)
        self.add_widget(self.layout)
        self.clock = None

    def on_enter(self):
        self.clock = Clock.schedule_interval(self._update, 1/60)

    def on_leave(self):
        if self.clock:
            self.clock.cancel()

    def _update(self, dt):
        self.canvas_widget.anim += dt
        self.canvas_widget.render()

    def on_touch_down(self, touch):
        cw = self.canvas_widget
        w, h = Window.size
        # Jogar
        btn_y = h * 0.38
        if h*0.34 < touch.y < h*0.44 and w*0.25 < touch.x < w*0.75:
            self.manager.current = 'game'
            return True
        # Continuar
        if h*0.28 < touch.y < h*0.35 and w*0.25 < touch.x < w*0.75:
            self.manager.current = 'game'
            return True
        return super().on_touch_down(touch)


class MenuCanvas(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.anim = 0

    def render(self):
        self.canvas.clear()
        w, h = self.width, self.height
        t = self.anim
        with self.canvas:
            # Fundo gradiente
            Color(0.04, 0.03, 0.02, 1)
            Rectangle(pos=(0, 0), size=(w, h))

            # Névoa de fundo
            for i in range(5):
                alpha = 0.04 + 0.02 * math.sin(t * 0.5 + i)
                rx = w * (0.1 + i * 0.2 + 0.05 * math.sin(t * 0.3 + i))
                ry = h * (0.3 + 0.1 * math.sin(t * 0.2 + i * 1.3))
                Color(0.3, 0.05, 0.05, alpha)
                Ellipse(pos=(rx - 100, ry - 60), size=(200, 120))

            # Linha de horizonte
            Color(0.35, 0.05, 0.05, 0.4)
            Line(points=[0, h*0.45, w, h*0.45], width=1)

            # Silhueta de cidade destruída
            self._draw_city_silhouette(w, h)

            # Lua
            Color(0.85, 0.82, 0.70, 0.9)
            lx = w * 0.75
            ly = h * 0.72
            Ellipse(pos=(lx-25, ly-25), size=(50, 50))
            Color(0.04, 0.03, 0.02, 0.6)
            Ellipse(pos=(lx-18, ly-20), size=(50, 50))

            # Estrelas
            for i in range(30):
                sx = (i * 137.5) % w
                sy = h * 0.5 + (i * 73.1) % (h * 0.45)
                alpha = 0.3 + 0.3 * math.sin(t * 2 + i * 0.7)
                Color(0.9, 0.88, 0.75, alpha)
                Ellipse(pos=(sx, sy), size=(2, 2))

            # TÍTULO
            self._draw_title(w, h, t)

            # Botões
            self._draw_buttons(w, h, t)

            # Rodapé
            self._draw_footer(w, h)

    def _draw_city_silhouette(self, w, h):
        # Prédios destruídos
        Color(0.07, 0.05, 0.04, 1)
        buildings = [
            (w*0.05, h*0.35, w*0.08, h*0.12),
            (w*0.12, h*0.30, w*0.06, h*0.17),
            (w*0.17, h*0.38, w*0.05, h*0.09),
            (w*0.22, h*0.28, w*0.07, h*0.19),
            (w*0.30, h*0.35, w*0.05, h*0.12),
            (w*0.60, h*0.32, w*0.07, h*0.15),
            (w*0.68, h*0.27, w*0.06, h*0.20),
            (w*0.75, h*0.34, w*0.08, h*0.13),
            (w*0.84, h*0.30, w*0.05, h*0.17),
            (w*0.90, h*0.36, w*0.06, h*0.11),
        ]
        for bx, by, bw, bh in buildings:
            Rectangle(pos=(bx, by), size=(bw, bh))
            # Janelas apagadas
            Color(0.12, 0.08, 0.05, 0.8)
            for wy in range(3):
                for wx in range(2):
                    Rectangle(pos=(bx+bw*0.15+wx*bw*0.4, by+bh*0.2+wy*bh*0.25),
                              size=(bw*0.2, bh*0.15))
            Color(0.07, 0.05, 0.04, 1)

    def _draw_title(self, w, h, t):
        # Sombra
        Color(0.5, 0.0, 0.0, 0.3)
        self._txt('ERMOS', w//2+3, h*0.68-3, 72, center=True)

        # Título principal
        Color(0.92, 0.86, 0.76, 1)
        self._txt('ERMOS', w//2, h*0.68, 72, center=True)

        # Subtítulo
        Color(0.65, 0.10, 0.10, 0.9)
        self._txt('CONSCIÊNCIA', w//2, h*0.61, 26, center=True)

        # Tagline pulsando
        alpha = 0.5 + 0.3 * math.sin(t * 1.5)
        Color(0.70, 0.65, 0.56, alpha)
        self._txt('viver não significa vencer', w//2, h*0.55, 14, center=True)

    def _draw_buttons(self, w, h, t):
        # Botão Jogar
        pulse = 0.05 * math.sin(t * 2)
        bw = 200
        bx = w//2 - bw//2
        by = h * 0.38
        bh = 46

        Color(0.40, 0.04, 0.04, 0.85)
        RoundedRectangle(pos=(bx, by), size=(bw, bh), radius=[8])
        Color(0.65, 0.10, 0.10, 0.9)
        Line(rectangle=(bx, by, bw, bh), width=1.2)
        Color(0.92, 0.85, 0.72, 1)
        self._txt('NOVA JORNADA', w//2, by + bh//2, 15, center=True)

        # Botão Continuar
        by2 = h * 0.30
        Color(0.15, 0.13, 0.10, 0.7)
        RoundedRectangle(pos=(bx, by2), size=(bw, bh-4), radius=[8])
        Color(0.4, 0.35, 0.25, 0.6)
        Line(rectangle=(bx, by2, bw, bh-4), width=1)
        Color(0.70, 0.65, 0.55, 0.8)
        self._txt('CONTINUAR', w//2, by2 + (bh-4)//2, 14, center=True)

    def _draw_footer(self, w, h):
        Color(0.35, 0.30, 0.22, 0.4)
        self._txt('v0.1 — © ERMOS CONSCIÊNCIA', w//2, 12, 9, center=True)

    def _txt(self, text, x, y, size, center=False):
        lbl = CoreLabel(text=str(text), font_size=size)
        lbl.refresh()
        tx = lbl.texture
        if center:
            Rectangle(texture=tx, pos=(x - tx.width//2, y - tx.height//2), size=tx.size)
        else:
            Rectangle(texture=tx, pos=(x, y), size=tx.size)
